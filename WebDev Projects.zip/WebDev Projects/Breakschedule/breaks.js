// No errors found in the selection.
